import mpi.*;

public class ArraySumMPI {

    public static void main(String[] args) throws Exception {
        MPI.Init(args);

        int rank = MPI.COMM_WORLD.Rank();
        int size = MPI.COMM_WORLD.Size();
        int ARRAY_SIZE = 16;
        int[] array = new int[ARRAY_SIZE];

        if (rank == 0) {
            for (int i = 0; i < ARRAY_SIZE; i++) {
                array[i] = i + 1;
            }
        }

        int subarray_size = ARRAY_SIZE / size;
        int[] subarray = new int[subarray_size];
        MPI.COMM_WORLD.Scatter(array, 0, subarray_size, MPI.INT, subarray, 0, subarray_size, MPI.INT, 0);

        int local_sum = 0;
        for (int i = 0; i < subarray_size; i++) {
            local_sum += subarray[i];
        }

        System.out.println("Process " + rank + " local sum is " + local_sum);

        int[] global_sum = new int[1];
        MPI.COMM_WORLD.Reduce(new int[]{local_sum}, 0, global_sum, 0, 1, MPI.INT, MPI.SUM, 0);

        if (rank == 0) {
            System.out.println("The sum of the elements is " + global_sum[0]);
        }

        MPI.Finalize();
    }
}