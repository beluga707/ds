Calculator:

![q1](https://user-images.githubusercontent.com/60461421/169646049-a2f55f8c-19b2-4ac2-ac0e-8587a98fcb97.png)

![q2](https://user-images.githubusercontent.com/60461421/169646057-de268156-bbb9-416b-a046-f79c8c797248.png)

![q3](https://user-images.githubusercontent.com/60461421/169646086-2bbc9e6b-93f1-4349-9575-f1a73b7f624f.png)

![q4](https://user-images.githubusercontent.com/60461421/169646095-052f6b76-0dd1-49b8-8bae-8fdc92934a8f.png)

There will be calculation results based on what you enter and press the calculate button.
